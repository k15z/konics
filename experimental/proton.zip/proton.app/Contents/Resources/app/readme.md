electron-packager . proton --platform=darwin --arch=x64
